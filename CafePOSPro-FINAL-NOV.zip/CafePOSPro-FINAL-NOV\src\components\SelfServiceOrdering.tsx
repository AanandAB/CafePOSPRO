import { useState, useEffect, useRef, useMemo } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { toast } from "sonner";
import { FeedbackForm } from "./FeedbackForm";

interface MenuItem {
  _id: Id<"inventory">;
  itemName: string;
  category: string;
  unitPrice: number;
  image?: string;
  isActive: boolean;
}

interface CartItem extends MenuItem {
  quantity: number;
  total: number;
  cookingInstructions?: string;
}

interface Table {
  _id: Id<"tables">;
  tableNumber: string;
  capacity: number;
  status: "available" | "occupied" | "reserved";
}

interface OrderItem {
  inventoryId: Id<"inventory">;
  itemName: string;
  quantity: number;
  unitPrice: number;
  total: number;
  cookingInstructions?: string;
  status: "pending" | "preparing" | "ready" | "served";
}

interface Order {
  _id: Id<"orders">;
  _creationTime: number;
  orderNumber: string;
  tableId?: Id<"tables">;
  items: {
    itemName: string;
    quantity: number;
    unitPrice: number;
    total: number;
    cookingInstructions?: string;
    status: "pending" | "preparing" | "ready" | "served";
  }[];
  subtotal: number;
  discount: number;
  tax: number;
  finalAmount: number;
  status: "active" | "completed" | "cancelled";
  paymentStatus: "pending" | "paid";
  paymentMode?: "cash" | "upi" | "card";
  waiterId?: Id<"staff">;
  cashierId?: Id<"staff">;
  notes?: string;
}

interface CustomerChatMessage {
  _id: Id<"customerChatMessages">;
  fromCustomerId: string;
  toUserId: Id<"staff">;
  message: string;
  timestamp: number;
  read: boolean;
  readAt?: number;
  tableId: Id<"tables">;
  tableName: string;
  isReply?: boolean;
}

export function SelfServiceOrdering({ tableId }: { tableId: string }) {
  const [customerName, setCustomerName] = useState("");
  const [showNameForm, setShowNameForm] = useState(true);
  const [activeCategory, setActiveCategory] = useState("All");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orderNote, setOrderNote] = useState("");
  const [tableInfo, setTableInfo] = useState<Table | null>(null);
  const [tableOrders, setTableOrders] = useState<Order[]>([]);
  const [previousOrderItems, setPreviousOrderItems] = useState<any>({});
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);
  const [tipAmount, setTipAmount] = useState(0);
  const [showTipOptions, setShowTipOptions] = useState(false);
  const [acceptedNotification, setAcceptedNotification] = useState<any>(null);
  const [loadingTimeout, setLoadingTimeout] = useState(false);
  const [customerMessage, setCustomerMessage] = useState(""); // New state for customer message
  const [showMessageForm, setShowMessageForm] = useState(false); // New state for message form visibility
  const [showChat, setShowChat] = useState(false); // New state for chat visibility
  const [chatMessage, setChatMessage] = useState(""); // New state for chat message
  const messagesEndRef = useRef<HTMLDivElement>(null); // Ref for scrolling to bottom of chat
  const loadingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Fetch inventory items (limited for better performance)
  const inventory = useQuery(api.inventory.getInventoryWithLimit, {
    limit: 100,
  });

  // Get unique categories
  const categories = useMemo(
    () => [
      "All",
      ...(inventory
        ? Array.from(new Set(inventory.map((item: MenuItem) => item.category)))
        : []),
    ],
    [inventory]
  );

  // Filter items by category
  const filteredItems = useMemo(
    () =>
      inventory
        ? activeCategory === "All"
          ? inventory
          : inventory.filter(
              (item: MenuItem) => item.category === activeCategory
            )
        : [],
    [inventory, activeCategory]
  );

  // Fetch table information
  const tables = useQuery(api.tables.getAllTables);

  // Fetch existing orders for this table
  const existingOrders = useQuery(api.orders.getOrdersByTable, {
    tableId: tableId as Id<"tables">,
  });

  // Fetch all staff members to show who accepted requests
  const allStaff = useQuery(api.staff.getAllStaff);

  // Get kitchen staff for chat (using existing allStaff query)
  const kitchenStaff = useMemo(() => {
    return (
      allStaff?.filter((staff) => staff.role === "kitchen" && staff.isActive) ||
      []
    );
  }, [allStaff]);

  // Fetch accepted notifications for this table
  const acceptedNotifications = useQuery(
    api.notifications.getAcceptedNotificationsForTable,
    {
      tableId: tableId as Id<"tables">,
    }
  );

  // Set up loading timeout
  useEffect(() => {
    // Clear any existing timeout
    if (loadingTimeoutRef.current) {
      clearTimeout(loadingTimeoutRef.current);
    }

    // Set new timeout for 10 seconds
    loadingTimeoutRef.current = setTimeout(() => {
      setLoadingTimeout(true);
    }, 10000);

    // Clear timeout on unmount
    return () => {
      if (loadingTimeoutRef.current) {
        clearTimeout(loadingTimeoutRef.current);
      }
    };
  }, []);

  // Clear timeout when data loads
  useEffect(() => {
    if (
      inventory &&
      tables &&
      existingOrders &&
      allStaff &&
      acceptedNotifications
    ) {
      if (loadingTimeoutRef.current) {
        clearTimeout(loadingTimeoutRef.current);
      }
    }
  }, [inventory, tables, existingOrders, allStaff, acceptedNotifications]);

  // Mutations
  const createOrder = useMutation(api.orders.createOrder);
  const updateTableStatus = useMutation(api.tables.updateTableStatus);
  const clearTableOrders = useMutation(api.orders.clearTableOrders);
  const notifyWaitersOfCustomerRequest = useMutation(
    api.notifications.notifyWaitersOfCustomerRequest
  );
  const notifyKitchenOfCustomerMessage = useMutation(
    api.notifications.notifyKitchenOfCustomerMessage
  );
  const sendCustomerChatMessage = useMutation(
    api.notifications.sendCustomerChatMessage
  );
  const customerChatMessages = useQuery(
    api.notifications.getCustomerChatMessagesForCustomer,
    {
      customerName: customerName || "",
    }
  );

  // Find table info
  useEffect(() => {
    if (tables && tableId) {
      const table = tables.find((t: Table) => t._id === tableId);
      setTableInfo(table || null);

      // Update table status to occupied
      if (table && table.status !== "occupied") {
        void updateTableStatus({
          tableId: table._id,
          status: "occupied",
        });
      }
    }
  }, [tables, tableId, updateTableStatus]);

  // Load existing orders for this table and check for status changes
  useEffect(() => {
    if (existingOrders && existingOrders.length > 0) {
      // Type assertion to ensure compatibility with Order interface
      setTableOrders(existingOrders as unknown as Order[]);

      // Filter orders that belong to the current customer
      const customerOrders = existingOrders.filter(
        (order) => order.notes && order.notes.includes(customerName)
      );

      // Check for status changes to show notifications for customer's own orders
      customerOrders.forEach((order: any) => {
        order.items.forEach((item: any) => {
          const key = `${order._id}-${item.itemName}`;
          const previousStatus = previousOrderItems[key];

          if (previousStatus !== item.status) {
            if (item.status === "preparing") {
              toast.info(`${item.itemName} is now being prepared`);
            } else if (item.status === "ready") {
              toast.success(`${item.itemName} is ready!`);
            }

            setPreviousOrderItems((prev: any) => ({
              ...prev,
              [key]: item.status,
            }));
          }
        });
      });
    }
  }, [existingOrders, customerName, previousOrderItems]);

  // Set the most recent accepted notification
  useEffect(() => {
    if (acceptedNotifications && acceptedNotifications.length > 0) {
      // Get the most recent accepted notification
      const latestNotification = acceptedNotifications[0];
      setAcceptedNotification(latestNotification);
    } else {
      setAcceptedNotification(null);
    }
  }, [acceptedNotifications]);

  // Handle customer name submission
  const handleNameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (customerName.trim()) {
      setShowNameForm(false);
      toast.success(`Welcome, ${customerName}! You can now start ordering.`);
    } else {
      toast.error("Please enter your name");
    }
  };

  // Call waiter function
  const callWaiter = async () => {
    try {
      await notifyWaitersOfCustomerRequest({
        type: "waiter_call",
        tableId: tableId as Id<"tables">,
        tableNumber: tableInfo?.tableNumber || "Unknown",
        message: `Customer ${customerName} needs assistance`,
      });
      toast.success(
        "Waiter has been notified! A waiter will be with you shortly."
      );
    } catch (error) {
      toast.error("Failed to notify waiter. Please try again.");
      console.error("Error calling waiter:", error);
    }
  };

  // Request water function
  const requestWater = async () => {
    try {
      await notifyWaitersOfCustomerRequest({
        type: "water_request",
        tableId: tableId as Id<"tables">,
        tableNumber: tableInfo?.tableNumber || "Unknown",
        message: `Customer ${customerName} requests water`,
      });
      toast.success(
        "Water request has been sent! A waiter will bring water shortly."
      );
    } catch (error) {
      toast.error("Failed to send water request. Please try again.");
      console.error("Error requesting water:", error);
    }
  };

  // Send message to kitchen function
  const sendMessageToKitchen = async () => {
    if (!customerMessage.trim()) {
      toast.error("Please enter a message");
      return;
    }

    try {
      await notifyKitchenOfCustomerMessage({
        tableId: tableId as Id<"tables">,
        tableNumber: tableInfo?.tableNumber || "Unknown",
        customerName,
        message: customerMessage,
      });
      toast.success("Message sent to kitchen staff!");
      setCustomerMessage("");
      setShowMessageForm(false);
    } catch (error) {
      toast.error("Failed to send message. Please try again.");
      console.error("Error sending message to kitchen:", error);
    }
  };

  // Send chat message to kitchen staff
  const sendChatMessage = async (toUserId: Id<"staff">) => {
    if (!chatMessage.trim()) {
      toast.error("Please enter a message");
      return;
    }

    try {
      await sendCustomerChatMessage({
        fromCustomerId: customerName,
        toUserId,
        message: chatMessage.trim(),
        tableId: tableId as Id<"tables">,
        tableName: tableInfo?.tableNumber || "Unknown",
      });
      setChatMessage("");
      toast.success("Message sent!");
    } catch (error) {
      toast.error("Failed to send message. Please try again.");
      console.error("Error sending chat message:", error);
    }
  };

  // Scroll to bottom of chat messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Get staff member name by ID
  const getStaffName = (staffId: Id<"staff">) => {
    const staffMember = allStaff?.find((s) => s._id === staffId);
    return staffMember ? staffMember.name : "Unknown Staff";
  };

  // Add item to cart
  const addToCart = (item: MenuItem) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find(
        (cartItem) => cartItem._id === item._id
      );
      if (existingItem) {
        return prevCart.map((cartItem) =>
          cartItem._id === item._id
            ? {
                ...cartItem,
                quantity: cartItem.quantity + 1,
                total: (cartItem.quantity + 1) * cartItem.unitPrice,
              }
            : cartItem
        );
      } else {
        return [
          ...prevCart,
          {
            ...item,
            quantity: 1,
            total: item.unitPrice,
          },
        ];
      }
    });
    toast.success(`${item.itemName} added to cart`);
  };

  // Remove item from cart
  const removeFromCart = (itemId: Id<"inventory">) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((item) => item._id === itemId);
      if (existingItem && existingItem.quantity > 1) {
        return prevCart.map((item) =>
          item._id === itemId
            ? {
                ...item,
                quantity: item.quantity - 1,
                total: (item.quantity - 1) * item.unitPrice,
              }
            : item
        );
      } else {
        return prevCart.filter((item) => item._id !== itemId);
      }
    });
  };

  // Update cooking instructions for an item in cart
  const updateCookingInstructions = (
    itemId: Id<"inventory">,
    instructions: string
  ) => {
    setCart((prevCart) => {
      return prevCart.map((item) =>
        item._id === itemId
          ? { ...item, cookingInstructions: instructions }
          : item
      );
    });
  };

  // Calculate cart totals
  const subtotal = cart.reduce((sum, item) => sum + item.total, 0);

  // Get system settings from localStorage
  const systemSettings = JSON.parse(
    localStorage.getItem("systemSettings") || "{}"
  );
  const enableGST = systemSettings.enableGST !== false; // Default to true if not set
  const taxRate = systemSettings.taxRate || 0.18; // Default to 18% if not set
  const tax = enableGST ? subtotal * taxRate : 0;
  const finalAmount = subtotal + tax;

  // Submit order
  const submitOrder = async () => {
    if (cart.length === 0) {
      toast.error("Please add items to your order");
      return;
    }

    try {
      const orderItems = cart.map((item: CartItem) => ({
        inventoryId: item._id,
        itemName: item.itemName,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        total: item.total,
        cookingInstructions: item.cookingInstructions,
        // Removed status field as it's not expected by the backend
      }));

      // Calculate subtotal, tax, and final amount
      const subtotal = cart.reduce(
        (sum: number, item: CartItem) => sum + item.total,
        0
      );

      // Get system settings from localStorage
      const systemSettings = JSON.parse(
        localStorage.getItem("systemSettings") || "{}"
      );
      const enableGST = systemSettings.enableGST !== false; // Default to true if not set
      const taxRate = systemSettings.taxRate || 0.18; // Default to 18% if not set
      const tax = enableGST ? subtotal * taxRate : 0;
      const finalAmount = subtotal + tax + tipAmount; // Include tip in final amount

      const result = await createOrder({
        tableId: tableId as Id<"tables">,
        items: orderItems,
        notes: orderNote
          ? `${customerName}: ${orderNote}`
          : `Order by ${customerName}`,
        enableGST: enableGST, // Pass GST setting to backend
        tipAmount: tipAmount, // Include tip amount
      });

      console.log("Order created successfully:", result);
      toast.success(
        "Order submitted successfully! A waiter will review your order."
      );
      setCart([]);
      setOrderNote("");
      setTipAmount(0); // Reset tip amount after order submission
      setShowTipOptions(false); // Hide tip options after order submission
    } catch (error) {
      console.error("Order submission error:", error);
      toast.error("Failed to submit order. Please try again.");
    }
  };

  // Reset and start new order
  const startNewOrder = () => {
    setCart([]);
    setOrderNote("");
    setShowNameForm(true);
    setCustomerName("");
  };

  // Clear table history when leaving
  const leaveTable = async () => {
    if (
      window.confirm(
        "Are you leaving the table? This will clear all order history for this table."
      )
    ) {
      try {
        // Clear table orders and update table status to available
        const result = await clearTableOrders({
          tableId: tableId as Id<"tables">,
        });
        console.log("Clear table result:", result);

        // Reset the customer session to show name form again
        setShowNameForm(true);
        setCustomerName("");
        setCart([]);
        setOrderNote("");

        toast.success("Table history cleared. Thank you for dining with us!");
      } catch (error) {
        console.error("Error clearing table:", error);
        toast.error("Failed to clear table history. Please try again.");
      }
    }
  };

  // Add this effect to scroll to bottom when chat messages change
  useEffect(() => {
    scrollToBottom();
  }, [showChat, chatMessage, customerChatMessages]);

  // Check if any queries are still loading
  const isLoading =
    (!inventory ||
      !tables ||
      !existingOrders ||
      !allStaff ||
      !acceptedNotifications) &&
    !loadingTimeout;

  // Check if any queries have errors
  const hasError =
    inventory === undefined ||
    tables === undefined ||
    existingOrders === undefined ||
    allStaff === undefined ||
    acceptedNotifications === undefined;

  if (isLoading) {
    return (
      <div className="flex flex-col justify-center items-center h-64 space-y-4">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-600"></div>
        <p className="text-gray-600">Loading menu and table information...</p>
        <div className="text-xs text-gray-500">
          {`Inventory: ${inventory ? "✓" : "⏳"} | Tables: ${tables ? "✓" : "⏳"} | Orders: ${existingOrders ? "✓" : "⏳"} | Staff: ${allStaff ? "✓" : "⏳"} | Notifications: ${acceptedNotifications ? "✓" : "⏳"}`}
        </div>
      </div>
    );
  }

  if (hasError || loadingTimeout) {
    return (
      <div className="flex flex-col justify-center items-center h-64 space-y-4">
        <div className="text-red-500 text-2xl">⚠️</div>
        <p className="text-gray-600">
          {loadingTimeout
            ? "Loading is taking longer than expected. Please check your connection."
            : "Error loading data. Please try refreshing the page."}
        </p>
        <button
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-amber-600 text-white rounded-lg font-medium hover:bg-amber-700 transition-colors"
        >
          Refresh Page
        </button>
      </div>
    );
  }

  // Show name form first
  if (showNameForm) {
    return (
      <div className="max-w-md mx-auto p-4">
        <div className="bg-white rounded-xl shadow-sm border border-amber-100 p-6">
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">👋</span>
            </div>
            <h1 className="text-2xl font-bold text-gray-900">
              Welcome to CafePOSPro
            </h1>
            <p className="text-gray-600 mt-2">
              Table {tableInfo?.tableNumber || tableId}
            </p>
          </div>

          <form onSubmit={handleNameSubmit} className="space-y-4">
            <div>
              <label
                htmlFor="customerName"
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                Your Name
              </label>
              <input
                type="text"
                id="customerName"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="Enter your name"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                autoFocus
              />
            </div>

            <button
              type="submit"
              className="w-full bg-amber-600 text-white py-3 rounded-lg font-medium hover:bg-amber-700 transition-colors"
            >
              Start Ordering
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-4">
      <div className="bg-gradient-to-r from-amber-500 to-orange-500 rounded-xl shadow-lg p-4 mb-4 sm:p-5 text-white">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold">CafePOSPro</h1>
            <p className="text-amber-100 text-sm sm:text-base">
              Table {tableInfo?.tableNumber || tableId}
            </p>
            <p className="text-amber-100 text-sm">
              Welcome, <span className="font-bold">{customerName}</span>!
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={startNewOrder}
              className="px-3 py-1.5 bg-white text-amber-600 rounded-lg text-sm font-medium hover:bg-amber-50 transition-colors whitespace-nowrap"
            >
              Change Name
            </button>
            <button
              onClick={() => {
                void leaveTable();
              }}
              className="px-3 py-1.5 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 transition-colors whitespace-nowrap"
            >
              Leave Table
            </button>
          </div>
        </div>

        {/* Waiter Call, Water Request, and Message to Kitchen Buttons - More compact */}
        <div className="flex flex-wrap gap-2 mt-3">
          <button
            onClick={() => {
              void callWaiter();
            }}
            className="flex-1 min-w-[100px] px-3 py-2.5 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-all flex items-center justify-center gap-1.5 shadow-sm text-sm"
          >
            <span className="text-base">🔔</span>
            <span>Call Waiter</span>
          </button>
          <button
            onClick={() => {
              void requestWater();
            }}
            className="flex-1 min-w-[100px] px-3 py-2.5 bg-cyan-600 text-white rounded-lg font-medium hover:bg-cyan-700 transition-all flex items-center justify-center gap-1.5 shadow-sm text-sm"
          >
            <span className="text-base">💧</span>
            <span>Request Water</span>
          </button>
          <button
            onClick={() => setShowChat(!showChat)}
            className="flex-1 min-w-[100px] px-3 py-2.5 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 transition-all flex items-center justify-center gap-1.5 shadow-sm text-sm"
          >
            <span className="text-base">💬</span>
            <span>{showChat ? "Hide Chat" : "Chat with Kitchen"}</span>
          </button>
        </div>

        <p className="text-amber-100 mt-2 text-center text-xs italic">
          Browse our menu and add items to your order
        </p>
      </div>

      {/* Customer Chat Panel */}
      {showChat && kitchenStaff && kitchenStaff.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-purple-200 p-4 mb-4">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">
            Chat with Kitchen Staff
          </h3>

          {/* Chat Interface - Simplified for customer */}
          <div className="space-y-3">
            <div className="bg-gray-50 rounded-lg p-3 h-64 overflow-y-auto">
              {customerChatMessages && customerChatMessages.length > 0 ? (
                <div className="space-y-2">
                  {customerChatMessages.map((msg: CustomerChatMessage) => (
                    <div
                      key={msg._id}
                      className={`flex ${
                        msg.isReply ? "justify-start" : "justify-end"
                      }`}
                    >
                      <div
                        className={`max-w-xs lg:max-w-md px-3 py-2 rounded-lg text-sm ${
                          msg.isReply
                            ? "bg-white border border-gray-200 mr-8"
                            : "bg-purple-600 text-white ml-8"
                        }`}
                      >
                        <p>{msg.message}</p>
                        <p
                          className={`text-xs mt-1 ${
                            msg.isReply ? "text-gray-500" : "text-purple-200"
                          }`}
                        >
                          {msg.isReply
                            ? `Kitchen • ${new Date(
                                msg.timestamp
                              ).toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}`
                            : `You • ${new Date(
                                msg.timestamp
                              ).toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}`}
                          {msg.tableName && ` at Table ${msg.tableName}`}
                        </p>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              ) : (
                <div className="text-center text-gray-500 py-8">
                  <p>No messages yet</p>
                  <p className="text-sm mt-1">
                    Send a message to start chatting with kitchen staff
                  </p>
                </div>
              )}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    // Send to all kitchen staff
                    kitchenStaff.forEach((staff) => {
                      void sendChatMessage(staff._id);
                    });
                  }
                }}
              />
              <button
                onClick={() => {
                  // Send to all kitchen staff
                  kitchenStaff.forEach((staff) => {
                    void sendChatMessage(staff._id);
                  });
                }}
                className="px-4 py-2 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 transition-colors"
              >
                Send
              </button>
            </div>

            <div className="text-xs text-gray-500">
              <p>
                Your messages will be sent to all available kitchen staff
                members.
              </p>
              <p className="mt-1">
                Available kitchen staff:{" "}
                {kitchenStaff.map((s) => s.name).join(", ")}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Message to Kitchen Form (previous implementation) */}
      {showMessageForm && (
        <div className="bg-white rounded-xl shadow-sm border border-purple-200 p-4 mb-4">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">
            Send Message to Kitchen
          </h3>
          <div className="space-y-3">
            <textarea
              value={customerMessage}
              onChange={(e) => setCustomerMessage(e.target.value)}
              placeholder="Enter your message for the kitchen staff..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              rows={3}
            />
            <div className="flex gap-2">
              <button
                onClick={() => {
                  void sendMessageToKitchen();
                }}
                className="flex-1 bg-purple-600 text-white py-2 rounded-lg font-medium hover:bg-purple-700 transition-colors"
              >
                Send Message
              </button>
              <button
                onClick={() => {
                  setShowMessageForm(false);
                  setCustomerMessage("");
                }}
                className="flex-1 bg-gray-300 text-gray-700 py-2 rounded-lg font-medium hover:bg-gray-400 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Waiter On The Way Notification - More compact */}
      {acceptedNotification && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <span className="text-xl">✅</span>
            </div>
            <div className="ml-2">
              <h3 className="text-sm font-medium text-green-800">
                Waiter on the way!
              </h3>
              <p className="text-xs text-green-700 mt-0.5">
                {getStaffName(acceptedNotification.acceptedBy)} is coming to
                your table
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Live Order Status - What others at the table are ordering */}
      {tableOrders && tableOrders.length > 0 && (
        <div className="bg-blue-50 rounded-lg p-3 mb-4 border border-blue-200">
          <h2 className="text-sm font-semibold text-blue-900 mb-2">
            Live Orders at Your Table
          </h2>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {tableOrders.map((order: Order) => (
              <div
                key={order._id}
                className="bg-white rounded-lg p-3 shadow-sm"
              >
                <div className="flex justify-between items-start mb-1.5">
                  <div>
                    <p className="font-medium text-gray-900 text-sm">
                      {order.orderNumber}
                    </p>
                    <p className="text-xs text-gray-500">
                      {order.notes
                        ? order.notes.split(":")[0]
                        : "Anonymous Customer"}
                    </p>
                  </div>
                  <span
                    className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${
                      order.status === "active"
                        ? "bg-amber-100 text-amber-800"
                        : order.status === "completed"
                          ? "bg-green-100 text-green-800"
                          : "bg-gray-100 text-gray-800"
                    }`}
                  >
                    {order.status}
                  </span>
                </div>

                <div className="mt-1.5 space-y-1.5">
                  {order.items.map((item, index) => (
                    <div key={index} className="flex justify-between text-xs">
                      <div className="flex-1">
                        <span className="font-medium">
                          {item.quantity}x {item.itemName}
                        </span>
                        {item.cookingInstructions && (
                          <p className="text-xs text-gray-500 mt-0.5">
                            Instructions: {item.cookingInstructions}
                          </p>
                        )}
                        <span
                          className={`ml-1 px-1 py-0.5 rounded text-xs ${
                            item.status === "pending"
                              ? "bg-yellow-100 text-yellow-800"
                              : item.status === "preparing"
                                ? "bg-blue-100 text-blue-800"
                                : item.status === "ready"
                                  ? "bg-green-100 text-green-800"
                                  : "bg-gray-100 text-gray-800"
                          }`}
                        >
                          {item.status}
                        </span>
                      </div>
                      <span className="font-medium">
                        ₹{item.total.toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>

                <p className="text-xs text-gray-500 mt-1.5">
                  Ordered at{" "}
                  {new Date(order._creationTime).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Customer's Own Orders with Status */}
      {tableOrders &&
        tableOrders.filter(
          (order) => order.notes && order.notes.includes(customerName)
        ).length > 0 && (
          <div className="bg-amber-50 rounded-lg p-3 mb-4 border border-amber-200">
            <h2 className="text-sm font-semibold text-amber-900 mb-2">
              Your Orders
            </h2>
            <div className="space-y-2 max-h-40 overflow-y-auto">
              {tableOrders
                .filter(
                  (order) => order.notes && order.notes.includes(customerName)
                )
                .map((order: Order) => (
                  <div
                    key={order._id}
                    className="bg-white rounded-lg p-3 shadow-sm border-l-2 border-amber-500"
                  >
                    <div className="flex justify-between items-start mb-1.5">
                      <div>
                        <p className="font-medium text-gray-900 text-sm">
                          Order #{order.orderNumber}
                        </p>
                        <p className="text-xs text-gray-500">
                          Placed at{" "}
                          {new Date(order._creationTime).toLocaleTimeString(
                            [],
                            { hour: "2-digit", minute: "2-digit" }
                          )}
                        </p>
                      </div>
                      <span
                        className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${
                          order.status === "active"
                            ? "bg-amber-100 text-amber-800"
                            : order.status === "completed"
                              ? "bg-green-100 text-green-800"
                              : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {order.status === "active"
                          ? "In Progress"
                          : order.status === "completed"
                            ? "Completed"
                            : "Cancelled"}
                      </span>
                    </div>

                    <div className="mt-1.5 space-y-1.5">
                      {order.items.map((item, index) => (
                        <div
                          key={index}
                          className="flex justify-between text-xs bg-amber-50 p-1.5 rounded"
                        >
                          <div className="flex-1">
                            <span className="font-medium">
                              {item.quantity}x {item.itemName}
                            </span>
                            {item.cookingInstructions && (
                              <p className="text-xs text-gray-600 mt-0.5">
                                Note: {item.cookingInstructions}
                              </p>
                            )}
                            <div className="flex items-center mt-1">
                              <span
                                className={`px-1.5 py-0.5 rounded-full text-xs font-medium ${
                                  item.status === "pending"
                                    ? "bg-yellow-100 text-yellow-800"
                                    : item.status === "preparing"
                                      ? "bg-blue-100 text-blue-800"
                                      : item.status === "ready"
                                        ? "bg-green-100 text-green-800"
                                        : "bg-gray-100 text-gray-800"
                                }`}
                              >
                                {item.status.charAt(0).toUpperCase() +
                                  item.status.slice(1)}
                              </span>
                              <span className="ml-1.5 text-xs text-gray-500">
                                {item.status === "pending" &&
                                  "Waiting to be prepared"}
                                {item.status === "preparing" &&
                                  "Being prepared"}
                                {item.status === "ready" && "Ready to serve"}
                                {item.status === "served" && "Served"}
                              </span>
                            </div>
                          </div>
                          <span className="font-medium">
                            ₹{item.total.toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className="flex justify-between items-center mt-2 pt-1.5 border-t border-gray-100">
                      <span className="font-medium text-gray-700 text-sm">
                        Total: ₹
                        {order.items
                          .reduce((sum, item) => sum + item.total, 0)
                          .toFixed(2)}
                      </span>
                      <span
                        className={`text-xs font-bold px-1.5 py-0.5 rounded-full ${
                          order.paymentStatus === "paid"
                            ? "text-green-600 bg-green-100"
                            : "text-amber-600 bg-amber-100"
                        }`}
                      >
                        {order.paymentStatus === "paid"
                          ? "✅ Paid"
                          : "💳 Pending Payment"}
                      </span>
                    </div>

                    {/* Payment Completion Message */}
                    {order.paymentStatus === "paid" && (
                      <div className="mt-2 p-2 bg-green-100 border border-green-200 rounded-lg">
                        <div className="flex items-center">
                          <span className="text-green-600 text-base mr-1.5">
                            ✓
                          </span>
                          <span className="text-green-800 font-bold text-sm">
                            Payment completed successfully!
                          </span>
                        </div>
                        <p className="text-green-700 text-xs mt-1">
                          Thank you for your order.
                        </p>
                      </div>
                    )}
                  </div>
                ))}
            </div>
          </div>
        )}

      {/* Main Content - Fixed Order Menu and Scrollable Menu Items */}
      <div className="flex flex-col lg:flex-row gap-4">
        {/* Scrollable Menu Items - Takes full width on mobile, 70% on desktop */}
        <div className="lg:w-7/12 flex flex-col">
          {/* Header with Feedback Button */}
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-lg font-bold text-gray-900">Menu</h2>
            <button
              onClick={() => setShowFeedbackForm(true)}
              className="px-3 py-1.5 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 transition-colors flex items-center gap-1.5 text-sm"
            >
              <span className="text-sm">💬</span>
              <span className="hidden sm:inline">Feedback</span>
            </button>
          </div>

          {/* Category Tabs - Horizontal scroll on mobile */}
          <div className="flex overflow-x-auto gap-1.5 mb-3 pb-1.5 scrollbar-hide">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-3 py-1.5 rounded-lg whitespace-nowrap flex-shrink-0 text-sm ${
                  activeCategory === category
                    ? "bg-amber-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Menu Items Grid - Scrollable on mobile */}
          <div
            className="flex-grow overflow-y-auto pr-1"
            style={{ maxHeight: "calc(100vh - 250px)" }}
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {filteredItems.map((item: MenuItem) => {
                // Check if item is already in cart
                const isInCart = cart.some(
                  (cartItem) => cartItem._id === item._id
                );
                const cartItem = cart.find(
                  (cartItem) => cartItem._id === item._id
                );

                return (
                  <div
                    key={item._id}
                    className={`rounded-lg border shadow-sm overflow-hidden hover:shadow transition-all ${
                      isInCart
                        ? "border-amber-500 bg-amber-50"
                        : "border-gray-200"
                    }`}
                  >
                    <div className="relative">
                      {item.image ? (
                        <img
                          src={item.image}
                          alt={item.itemName}
                          className="w-full h-20 object-cover"
                          loading="lazy"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src =
                              "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80' viewBox='0 0 24 24' fill='none' stroke='%23ccc' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='3' width='18' height='18' rx='2' ry='2'%3E%3C/rect%3E%3Ccircle cx='8.5' cy='8.5' r='1.5'%3E%3C/circle%3E%3Cpath d='M21 15l-5-5L5 21'%3E%3C/path%3E%3C/svg%3E";
                          }}
                        />
                      ) : (
                        <div className="w-full h-20 bg-gray-100 flex items-center justify-center">
                          <span className="text-gray-400 text-xs">
                            No Image
                          </span>
                        </div>
                      )}
                      {!item.isActive && (
                        <div className="absolute top-1 right-1 bg-red-500 text-white text-xs px-1 py-0.5 rounded">
                          Unavailable
                        </div>
                      )}
                    </div>

                    <div className="p-2.5">
                      <div className="flex justify-between items-start mb-1">
                        <h3 className="font-medium text-gray-900 text-xs leading-tight">
                          {item.itemName}
                        </h3>
                        <p className="font-bold text-amber-600 text-xs">
                          ₹{item.unitPrice.toFixed(2)}
                        </p>
                      </div>

                      <div className="flex items-center justify-between mt-1.5 gap-1">
                        {isInCart ? (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => removeFromCart(item._id)}
                              className="w-5 h-5 rounded-full bg-amber-600 text-white flex items-center justify-center text-xs font-bold hover:bg-amber-700 transition-colors"
                              disabled={!item.isActive}
                            >
                              -
                            </button>
                            <span className="w-5 text-center text-xs font-medium">
                              {cartItem?.quantity}
                            </span>
                            <button
                              onClick={() => addToCart(item)}
                              className="w-5 h-5 rounded-full bg-amber-600 text-white flex items-center justify-center text-xs font-bold hover:bg-amber-700 transition-colors"
                              disabled={!item.isActive}
                            >
                              +
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => addToCart(item)}
                            disabled={!item.isActive}
                            className={`flex-1 py-1 rounded text-xs font-medium transition-colors ${
                              item.isActive
                                ? "bg-amber-600 text-white hover:bg-amber-700"
                                : "bg-gray-300 text-gray-500 cursor-not-allowed"
                            }`}
                          >
                            {item.isActive ? "Add" : "Unavailable"}
                          </button>
                        )}

                        {isInCart && (
                          <div className="text-right">
                            <p className="font-medium text-gray-900 text-xs">
                              ₹
                              {(cartItem!.quantity * item.unitPrice).toFixed(2)}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Fixed Order Menu - Takes full width on mobile, 30% on desktop */}
        <div className="lg:w-5/12">
          <div className="bg-white rounded-xl shadow-sm border border-amber-100 p-3 sticky top-4 h-fit">
            <div className="flex justify-between items-center mb-3">
              <h2 className="text-base font-semibold text-gray-900">
                Your Order
              </h2>
              {cart.length > 0 && (
                <span className="bg-amber-100 text-amber-800 text-xs font-medium px-2 py-0.5 rounded-full">
                  {cart.reduce((sum, item) => sum + item.quantity, 0)} items
                </span>
              )}
            </div>

            {cart.length === 0 ? (
              <div className="text-center py-6">
                <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-xl">🛒</span>
                </div>
                <p className="text-gray-500 text-sm">No items added yet</p>
                <p className="text-gray-400 text-xs mt-1">
                  Select items from the menu
                </p>
              </div>
            ) : (
              <>
                <div className="space-y-2 mb-3 max-h-40 overflow-y-auto">
                  {cart.map((item) => (
                    <div
                      key={item._id}
                      className="border-b pb-2 bg-amber-50 rounded-lg p-2"
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">
                            {item.itemName}
                          </p>
                          <p className="text-xs text-gray-600">
                            ₹{item.unitPrice} × {item.quantity}
                          </p>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => removeFromCart(item._id)}
                            className="w-5 h-5 rounded-full bg-gray-200 flex items-center justify-center text-xs hover:bg-gray-300"
                          >
                            -
                          </button>
                          <span className="w-6 text-center text-xs font-medium">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => addToCart(item)}
                            className="w-5 h-5 rounded-full bg-amber-600 text-white flex items-center justify-center text-xs hover:bg-amber-700"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      {/* Cooking Instructions for Cart Items */}
                      <div className="mt-1.5">
                        <input
                          type="text"
                          placeholder="Special instructions"
                          value={item.cookingInstructions || ""}
                          onChange={(e) =>
                            updateCookingInstructions(item._id, e.target.value)
                          }
                          className="w-full px-1.5 py-1 text-xs border border-gray-300 rounded focus:ring-1 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>

                      <p className="text-right font-medium mt-1 text-sm">
                        ₹{item.total.toFixed(2)}
                      </p>
                    </div>
                  ))}
                </div>

                <div className="border-t pt-2 space-y-1.5 text-sm">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>₹{subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>
                      Tax{" "}
                      {enableGST
                        ? `(${(taxRate * 100).toFixed(0)}%)`
                        : "(Disabled)"}
                    </span>
                    <span>₹{tax.toFixed(2)}</span>
                  </div>

                  {/* Tip Section */}
                  <div className="border-t border-gray-200 pt-1.5">
                    <div className="flex justify-between items-center">
                      <span>Tip</span>
                      <div className="flex items-center gap-1.5">
                        <span className="font-medium">
                          ₹{tipAmount.toFixed(2)}
                        </span>
                        <button
                          onClick={() => setShowTipOptions(!showTipOptions)}
                          className="text-amber-600 hover:text-amber-700 text-xs"
                        >
                          {showTipOptions ? "Hide" : "Add"}
                        </button>
                      </div>
                    </div>

                    {showTipOptions && (
                      <div className="mt-1.5 space-y-1.5">
                        <div className="flex gap-1.5">
                          {[0, 10, 20, 50, 100].map((amount) => (
                            <button
                              key={amount}
                              onClick={() => setTipAmount(amount)}
                              className={`px-1.5 py-0.5 text-xs rounded ${
                                tipAmount === amount
                                  ? "bg-amber-600 text-white"
                                  : "bg-gray-100 text-gray-700"
                              }`}
                            >
                              {amount === 0 ? "No Tip" : `₹${amount}`}
                            </button>
                          ))}
                        </div>
                        <div className="flex gap-1.5">
                          <input
                            type="number"
                            value={tipAmount}
                            onChange={(e) =>
                              setTipAmount(Number(e.target.value))
                            }
                            className="flex-1 px-1.5 py-0.5 text-xs border border-gray-300 rounded"
                            placeholder="Custom"
                          />
                          <button
                            onClick={() => setTipAmount(0)}
                            className="px-1.5 py-0.5 bg-gray-200 text-gray-700 rounded text-xs"
                          >
                            Clear
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex justify-between font-semibold text-base border-t border-gray-200 pt-1.5">
                    <span>Total</span>
                    <span>₹{finalAmount.toFixed(2)}</span>
                  </div>
                </div>

                <div className="mt-3">
                  <textarea
                    value={orderNote}
                    onChange={(e) => setOrderNote(e.target.value)}
                    placeholder="Special instructions (optional)"
                    className="w-full p-1.5 border border-gray-300 rounded-lg mb-2 text-sm"
                    rows={2}
                  />
                  <button
                    onClick={() => {
                      void submitOrder();
                    }}
                    className="w-full bg-green-600 text-white py-2.5 rounded-lg font-medium hover:bg-green-700 transition-colors text-sm"
                  >
                    Submit Order
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Feedback Form Modal */}
      {showFeedbackForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-4">
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-lg font-bold text-gray-900">
                  Share Your Experience
                </h3>
                <button
                  onClick={() => setShowFeedbackForm(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <span className="text-xl">×</span>
                </button>
              </div>
              <FeedbackForm
                tableId={tableId}
                customerName={customerName}
                onFeedbackSubmitted={() => {
                  setShowFeedbackForm(false);
                  toast.success("Thank you for your feedback!");
                }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
